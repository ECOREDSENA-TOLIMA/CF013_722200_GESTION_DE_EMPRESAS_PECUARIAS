module.exports = 'Plan de mercadeo en la empresa pecuaria'
